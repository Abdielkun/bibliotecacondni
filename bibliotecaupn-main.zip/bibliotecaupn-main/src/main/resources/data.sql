-- =====================================================
-- ✅ INSERCIÓN SEGURA DEL ADMINISTRADOR (solo si no existe)
-- =====================================================
INSERT INTO usuario (nombre, email, username, password, rol, dni)
SELECT 
    'Admin Principal',
    'admin@biblioteca.com',
    'admin',
    '$2a$10$Ag7Efiw./RXYaw1amV9Xy.1EwB8SZVw0jCb3NnX1/F5f9egDPne9y',  -- Contraseña: adminpass
    'ROLE_ADMIN',
    '00000000'
WHERE NOT EXISTS (SELECT 1 FROM usuario WHERE dni = '00000000');

-- =====================================================
-- 📚 INSERCIÓN SEGURA DE LIBRO DE EJEMPLO
-- =====================================================
INSERT INTO libro (titulo, autor, isbn, editorial, disponible, version)
SELECT 
    'El arte de la guerra',
    'Sun Tzu',
    '978-0123456789',
    'Editorial UPN',
    1,
    0
WHERE NOT EXISTS (SELECT 1 FROM libro WHERE isbn = '978-0123456789');

-- =====================================================
-- 📦 INSERCIÓN DE PRÉSTAMO DE PRUEBA (solo si existen registros)
-- =====================================================
INSERT INTO prestamo (libro_id, usuario_id, fecha_prestamo, fecha_devolucion, renovado)
SELECT 1, 1, '2025-10-01', '2025-10-15', 0
WHERE EXISTS (SELECT 1 FROM usuario WHERE id = 1)
  AND EXISTS (SELECT 1 FROM libro WHERE id = 1)
  AND NOT EXISTS (SELECT 1 FROM prestamo WHERE usuario_id = 1 AND libro_id = 1);
