package com.upnbiblioteca.security;

import com.upnbiblioteca.model.Usuario;
import com.upnbiblioteca.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    @Autowired
    private UsuarioService usuarioService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // mismo encoder en todo el proyecto
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return username -> {
            logger.info("Intentando autenticar: {}", username);

            Usuario u = usuarioService.findByUsername(username);
            if (u == null) {
                logger.warn("No existe el usuario: {}", username);
                throw new UsernameNotFoundException("Usuario no encontrado: " + username);
            }

            // Usa AUTHORITIES para NO tocar el prefijo ROLE_
            // Si en BD tienes "ROLE_ADMIN" o "ROLE_USER", se usan tal cual.
            return User.withUsername(u.getUsername())
                    .password(u.getPassword()) // hash BCrypt de la BD
                    .authorities(Collections.singletonList(new SimpleGrantedAuthority(u.getRol())))
                    .build();
        };
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
           .authorizeHttpRequests(auth -> auth
               .requestMatchers(
                   "/login", "/register",
                   "/css/**", "/js/**", "/img/**",
                   "/plugins/**", "/webjars/**",
                   "/usuarios/api/dni/**"
               ).permitAll()

               .requestMatchers("/", "/index", "/dashboard").authenticated()

               // ADMIN
               .requestMatchers("/usuarios/**", "/libros/**", "/prestamos/**", "/reportes/**", "/configuracion/**")
                   .hasAuthority("ROLE_ADMIN")

               // USER (y admin también puede entrar)
               .requestMatchers("/usuario/**", "/perfil/**")
                   .hasAnyAuthority("ROLE_USER", "ROLE_ADMIN")

               .anyRequest().authenticated()
           )
           .formLogin(form -> form
               .loginPage("/login")
               .usernameParameter("username")
               .passwordParameter("password")
               .successHandler(successHandler())   // redirección por rol
               .failureUrl("/login?error=true")
               .permitAll()
           )
           .logout(logout -> logout
               .logoutUrl("/logout")
               .logoutSuccessUrl("/login?logout=true")
               .invalidateHttpSession(true)
               .deleteCookies("JSESSIONID")
               .permitAll()
           );

        return http.build();
    }

    @Bean
    public AuthenticationSuccessHandler successHandler() {
        return (request, response, authentication) -> {
            boolean isAdmin = authentication.getAuthorities().stream()
                    .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

            if (isAdmin) {
                response.sendRedirect("/index");               // tu vista de admin (templates/index.html)
            } else {
                response.sendRedirect("/usuario/dashboard");   // tu vista de usuario (templates/usuario/dashboard.html)
            }
        };
    }
}
