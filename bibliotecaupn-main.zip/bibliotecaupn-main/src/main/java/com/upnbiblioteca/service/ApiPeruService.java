package com.upnbiblioteca.service;

import com.upnbiblioteca.model.ApiPeruDniData;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ApiPeruService {

    @Value("${apiperu.token}")
    private String token;

    @Value("${apiperu.url.dni}")
    private String dniUrl;

    private final RestTemplate restTemplate;

    public ApiPeruService(RestTemplateBuilder builder) {
        this.restTemplate = builder.build();
    }

    public Optional<ApiPeruDniData.DniData> consultarPorDni(String dni) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(token);

        Map<String, String> body = Map.of("dni", dni);
        HttpEntity<Map<String, String>> request = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<ApiPeruDniData> resp = restTemplate.postForEntity(dniUrl, request, ApiPeruDniData.class);
            if (resp.getStatusCode().is2xxSuccessful() && resp.getBody() != null && resp.getBody().isSuccess()) {
                return Optional.of(resp.getBody().getData());
            }
        } catch (RestClientException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }
}
