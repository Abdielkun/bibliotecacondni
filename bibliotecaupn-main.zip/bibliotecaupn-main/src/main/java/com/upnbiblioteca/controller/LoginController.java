package com.upnbiblioteca.controller;

import com.upnbiblioteca.model.Usuario;
import com.upnbiblioteca.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LoginController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/login")
    public String login() {
        return "login"; // templates/login.html
    }

    @GetMapping("/register")
    public String showRegister(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "register"; // templates/register.html
    }

    @PostMapping("/register")
    public String register(@ModelAttribute("usuario") Usuario usuario,
                           RedirectAttributes ra) {

        if (usuarioService.existsByUsername(usuario.getUsername())) {
            ra.addFlashAttribute("error", "El nombre de usuario ya está en uso.");
            return "redirect:/register";
        }

        // Rol seguro
        String rol = usuario.getRol();
        if (rol == null || (!rol.equals("ROLE_ADMIN") && !rol.equals("ROLE_USER"))) {
            rol = "ROLE_USER";
        }
        usuario.setRol(rol);

        // Encriptar password
        usuario.setPassword(passwordEncoder.encode(usuario.getPassword()));

        usuarioService.save(usuario);
        ra.addFlashAttribute("success", "Registro exitoso. Ya puedes iniciar sesión.");
        return "redirect:/login";
    }
}
