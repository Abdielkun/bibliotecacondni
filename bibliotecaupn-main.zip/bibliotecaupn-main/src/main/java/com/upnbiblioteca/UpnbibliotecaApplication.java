package com.upnbiblioteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpnbibliotecaApplication {

    public static void main(String[] args) {
        SpringApplication.run(UpnbibliotecaApplication.class, args);
    }
}
